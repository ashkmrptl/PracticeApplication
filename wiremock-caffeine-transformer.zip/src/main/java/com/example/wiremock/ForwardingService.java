package com.example.wiremock;

import org.apache.hc.client5.http.impl.classic.HttpClientBuilder;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManager;
import org.apache.hc.client5.http.ssl.SSLConnectionSocketFactory;
import org.apache.hc.core5.ssl.SSLContexts;
import org.apache.hc.core5.ssl.TrustStrategy;
import org.springframework.http.*;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;
import com.github.tomakehurst.wiremock.http.Request;

import javax.net.ssl.SSLContext;
import java.io.FileInputStream;
import java.security.KeyStore;
import java.util.Objects;

public class ForwardingService {

    private final RestTemplate restTemplate;
    private final String baseUrl;

    public ForwardingService() {
        this.baseUrl = Objects.requireNonNull(System.getenv("FORWARD_BASE_URL"), "FORWARD_BASE_URL is required");
        this.restTemplate = createSecureRestTemplate();
    }

    public String forward(Request request) {
        HttpHeaders headers = new HttpHeaders();
        request.getAllHeaderKeys().forEach(header -> headers.set(header, request.getHeader(header)));
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<String> entity = new HttpEntity<>(request.getBodyAsString(), headers);
        String targetUrl = baseUrl + request.getUrl();

        ResponseEntity<String> response = restTemplate.postForEntity(targetUrl, entity, String.class);
        return response.getBody();
    }

    private RestTemplate createSecureRestTemplate() {
        try {
            String truststorePath = System.getenv("TRUSTSTORE_PATH");
            String truststorePassword = System.getenv("TRUSTSTORE_PASSWORD");
            String keystorePath = System.getenv("KEYSTORE_PATH");
            String keystorePassword = System.getenv("KEYSTORE_PASSWORD");

            KeyStore truststore = KeyStore.getInstance(KeyStore.getDefaultType());
            truststore.load(new FileInputStream(truststorePath), truststorePassword.toCharArray());

            KeyStore keystore = KeyStore.getInstance(KeyStore.getDefaultType());
            keystore.load(new FileInputStream(keystorePath), keystorePassword.toCharArray());

            SSLContext sslContext = SSLContexts.custom()
                    .loadTrustMaterial(truststore, null)
                    .loadKeyMaterial(keystore, keystorePassword.toCharArray())
                    .build();

            SSLConnectionSocketFactory sslSocketFactory = new SSLConnectionSocketFactory(sslContext);
            HttpClientBuilder httpClientBuilder = HttpClientBuilder.create()
                    .setSSLSocketFactory(sslSocketFactory)
                    .setConnectionManager(new PoolingHttpClientConnectionManager());

            HttpComponentsClientHttpRequestFactory factory =
                    new HttpComponentsClientHttpRequestFactory(httpClientBuilder.build());

            return new RestTemplate(factory);
        } catch (Exception e) {
            throw new RuntimeException("Failed to configure SSL for RestTemplate", e);
        }
    }
}
