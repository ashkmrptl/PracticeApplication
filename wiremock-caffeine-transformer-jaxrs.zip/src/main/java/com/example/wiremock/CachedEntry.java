package com.example.wiremock;

public class CachedEntry {
    public final String body;
    public int calls;
    public long lastUpdated;

    public CachedEntry(String body, int calls, long lastUpdated) {
        this.body = body;
        this.calls = calls;
        this.lastUpdated = lastUpdated;
    }

    public boolean needsRefresh() {
        return calls >= 1000 || System.currentTimeMillis() - lastUpdated >= 24 * 60 * 60 * 1000L;
    }
}
