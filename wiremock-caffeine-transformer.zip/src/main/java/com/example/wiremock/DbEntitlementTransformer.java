package com.example.wiremock;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.extension.*;
import com.github.tomakehurst.wiremock.http.*;

public class DbEntitlementTransformer extends ResponseTransformer {
    private static final ObjectMapper mapper = new ObjectMapper();
    private final ForwardingService forwardingService = new ForwardingService();
    private final CacheManager cacheManager = new CacheManager();

    @Override
    public Response transform(Request request, Response response, FileSource files, Parameters parameters) {
        if (!request.getMethod().equals(RequestMethod.POST)) return response;

        try {
            JsonNode body = mapper.readTree(request.getBodyAsString());
            String userId = body.path("userId").asText();
            String apiName = request.getUrl().substring(request.getUrl().lastIndexOf('/') + 1);
            String cacheKey = userId + "_" + apiName;

            CachedEntry entry = cacheManager.get(cacheKey);
            if (entry != null) {
                return Response.Builder.like(response).but()
                        .body(entry.body)
                        .status(200)
                        .build();
            }

            String freshResponse = forwardingService.forward(request);
            cacheManager.put(cacheKey, freshResponse);

            return Response.Builder.like(response).but()
                    .body(freshResponse)
                    .status(200)
                    .build();

        } catch (Exception e) {
            e.printStackTrace();
            return Response.Builder.like(response).but()
                    .status(500)
                    .body("{"error": "Transformer error"}")
                    .build();
        }
    }

    @Override
    public String getName() {
        return "db-entitlement-transformer";
    }

    @Override
    public boolean applyGlobally() {
        return false;
    }
}
