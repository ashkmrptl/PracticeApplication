package com.example.wiremock;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.github.benmanes.caffeine.cache.*;

import java.io.*;
import java.nio.file.*;
import java.util.concurrent.TimeUnit;

public class CacheManager {
    private static final String CACHE_DIR = "cache";
    private static final ObjectMapper mapper = new ObjectMapper();

    private final LoadingCache<String, CachedEntry> cache;

    public CacheManager() {
        new File(CACHE_DIR).mkdirs();
        this.cache = Caffeine.newBuilder()
                .expireAfterWrite(48, TimeUnit.HOURS)
                .maximumSize(10_000)
                .build(this::loadFromDisk);
    }

    public CachedEntry get(String key) {
        CachedEntry entry = cache.get(key);
        if (entry != null && entry.needsRefresh()) {
            cache.invalidate(key);
            return null;
        }
        if (entry != null) {
            entry.calls++;
            persistToDisk(key, entry);
        }
        return entry;
    }

    public void put(String key, String body) {
        CachedEntry newEntry = new CachedEntry(body, 1, System.currentTimeMillis());
        cache.put(key, newEntry);
        persistToDisk(key, newEntry);
    }

    private CachedEntry loadFromDisk(String key) {
        try {
            Path bodyPath = Paths.get(CACHE_DIR, key + ".json");
            Path metaPath = Paths.get(CACHE_DIR, key + "_meta.json");
            if (!Files.exists(bodyPath)) return null;

            String body = Files.readString(bodyPath);
            int calls = 0;
            long lastUpdated = System.currentTimeMillis();

            if (Files.exists(metaPath)) {
                ObjectNode meta = (ObjectNode) mapper.readTree(metaPath.toFile());
                calls = meta.path("calls").asInt(0);
                lastUpdated = meta.path("lastUpdated").asLong(lastUpdated);
            }

            return new CachedEntry(body, calls, lastUpdated);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private void persistToDisk(String key, CachedEntry entry) {
        try {
            Files.writeString(Paths.get(CACHE_DIR, key + ".json"), entry.body);
            ObjectNode meta = mapper.createObjectNode();
            meta.put("calls", entry.calls);
            meta.put("lastUpdated", entry.lastUpdated);
            Files.write(Paths.get(CACHE_DIR, key + "_meta.json"),
                    mapper.writerWithDefaultPrettyPrinter().writeValueAsBytes(meta));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
