package com.example.wiremock;

import com.github.tomakehurst.wiremock.http.Request;
import org.apache.hc.client5.http.classic.methods.HttpPost;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManager;
import org.apache.hc.client5.http.ssl.SSLConnectionSocketFactory;
import org.apache.hc.core5.http.ContentType;
import org.apache.hc.core5.http.io.entity.StringEntity;
import org.apache.hc.core5.ssl.SSLContexts;

import javax.net.ssl.SSLContext;
import java.io.FileInputStream;
import java.security.KeyStore;
import java.util.Objects;
import java.util.Scanner;

public class ForwardingService {

    private final String baseUrl;
    private final CloseableHttpClient httpClient;

    public ForwardingService() {
        this.baseUrl = Objects.requireNonNull(System.getenv("FORWARD_BASE_URL"), "FORWARD_BASE_URL is required");
        this.httpClient = createSecureHttpClient();
    }

    public String forward(Request request) {
        try {
            String targetUrl = baseUrl + request.getUrl();
            HttpPost post = new HttpPost(targetUrl);
            post.setEntity(new StringEntity(request.getBodyAsString(), ContentType.APPLICATION_JSON));
            request.getAllHeaderKeys().forEach(h -> post.setHeader(h, request.getHeader(h)));

            return httpClient.execute(post, httpResponse -> {
                Scanner s = new Scanner(httpResponse.getEntity().getContent()).useDelimiter("\A");
                return s.hasNext() ? s.next() : "";
            });
        } catch (Exception e) {
            throw new RuntimeException("Failed to forward request", e);
        }
    }

    private CloseableHttpClient createSecureHttpClient() {
        try {
            String truststorePath = System.getenv("TRUSTSTORE_PATH");
            String truststorePassword = System.getenv("TRUSTSTORE_PASSWORD");
            String keystorePath = System.getenv("KEYSTORE_PATH");
            String keystorePassword = System.getenv("KEYSTORE_PASSWORD");

            KeyStore truststore = KeyStore.getInstance(KeyStore.getDefaultType());
            truststore.load(new FileInputStream(truststorePath), truststorePassword.toCharArray());

            KeyStore keystore = KeyStore.getInstance(KeyStore.getDefaultType());
            keystore.load(new FileInputStream(keystorePath), keystorePassword.toCharArray());

            SSLContext sslContext = SSLContexts.custom()
                    .loadTrustMaterial(truststore, null)
                    .loadKeyMaterial(keystore, keystorePassword.toCharArray())
                    .build();

            return HttpClients.custom()
                    .setConnectionManager(new PoolingHttpClientConnectionManager())
                    .setSSLSocketFactory(new SSLConnectionSocketFactory(sslContext))
                    .build();

        } catch (Exception e) {
            throw new RuntimeException("Failed to configure SSL HTTP client", e);
        }
    }
}
